package com.example.finalproject.demo.repository;

import java.util.List;

import com.example.finalproject.demo.entity.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface PetRepository extends JpaRepository<Pet, Long> {

    @Query("SELECT b FROM Pet b WHERE b.pet_breed LIKE %?1%" + " OR b.pet_name LIKE %?1%" + " OR b.pet_gender LIKE %?1%")
    public List<Pet> search(String keyword);
}