package com.example.finalproject.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "pets")
public class Pet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "pet_name", length = 50, nullable = false, unique = true)
    private String pet_name;

    @Column(name = "pet_breed", length = 100, nullable = false)
    private String pet_breed;

    @Column(name = "pet_gender", length = 50, nullable = false)
    private String pet_gender;

    @Column(name = "cost", length = 250, nullable = false)
    private int cost;

    @ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE })
    @JoinTable(name = "pets_authors", joinColumns = { @JoinColumn(name = "pet_id") }, inverseJoinColumns = {
            @JoinColumn(name = "author_id") })
    private Set<Author> authors = new HashSet<Author>();

    @ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinTable(name = "pets_categories", joinColumns = { @JoinColumn(name = "pet_id") }, inverseJoinColumns = {
            @JoinColumn(name = "category_id") })
    private Set<Category> categories = new HashSet<Category>();

//	@ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
//	@JoinTable(name = "pets_publishers", joinColumns = { @JoinColumn(name = "pet_id") }, inverseJoinColumns = {
//			@JoinColumn(name = "publisher_id") })
//	private Set<Publisher> publishers = new HashSet<Publisher>();

    public Pet(String pet_name, String pet_breed, String pet_gender, int cost) {
        this.pet_name = pet_name;
        this.pet_breed = pet_breed;
        this.pet_gender = pet_gender;
        this.cost = cost;
    }

    public void addAuthors(Author author) {
        this.authors.add(author);
        author.getBooks().add(this);
    }

    public void removeAuthors(Author author) {
        this.authors.remove(author);
        author.getBooks().remove(this);
    }

    public void addCategories(Category category) {
        this.categories.add(category);
        category.getBooks().add(this);
    }

    public void removeCategories(Category category) {
        this.categories.remove(category);
        category.getBooks().remove(this);
    }

//	public void addPublishers(Publisher publisher) {
//		this.publishers.add(publisher);
//		publisher.getBooks().add(this);
//	}
//
//	public void removePublishers(Publisher publisher) {
//		this.publishers.remove(publisher);
//		publisher.getBooks().remove(this);
//	}
}

