package com.example.finalproject.demo.service;

import com.example.finalproject.demo.entity.Pet;

import java.util.List;


public interface PetService {

    public List<Pet> findAllPets();

    public List<Pet> searchPets(String keyword);

    public Pet findPetById(Long id);

    public void createPet(Pet pet);

    public void updatePet(Pet pet);

    public void deletePet(Long id);

}
