package com.example.finalproject.demo.service.impl;

import java.util.List;

import com.example.finalproject.demo.entity.Pet;
import com.example.finalproject.demo.exception.NotFoundException;
import com.example.finalproject.demo.repository.PetRepository;
import com.example.finalproject.demo.service.PetService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;



@Service
public class PetServiceImpl implements PetService {

    private final PetRepository petRepository;

    public PetServiceImpl(PetRepository petRepository) {
        this.petRepository = petRepository;
    }

    @Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
    @Override
    public List<Pet> findAllPets() {
        return petRepository.findAll();
    }

    @Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
    @Override
    public List<Pet> searchPets(String keyword) {
        if (keyword != null) {
            return petRepository.search(keyword);
        }
        return petRepository.findAll();
    }

    @Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
    @Override
    public Pet findPetById(Long id) {
        return petRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(String.format("Pet not found with ID %d", id)));
    }

    @Override
    public void createPet(Pet pet) {
        petRepository.save(pet);
    }

    @Override
    public void updatePet(Pet pet) {
        petRepository.save(pet);
    }

    @Override
    public void deletePet(Long id) {
        final Pet pet = petRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(String.format("Pet not found with ID %d", id)));

        petRepository.deleteById(pet.getId());
    }

}

