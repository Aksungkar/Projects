package com.example.finalproject.demo.controller;

import java.util.List;

import com.example.finalproject.demo.entity.Pet;
import com.example.finalproject.demo.service.AuthorService;
import com.example.finalproject.demo.service.CategoryService;
import com.example.finalproject.demo.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class PetController {

    private final PetService petService;
    private final AuthorService authorService;
    private final CategoryService categoryService;
//	private final PublisherService publisherService;

    @Autowired
//	PublisherService publisherService
    public PetController(PetService petService, AuthorService authorService, CategoryService categoryService
    ) {
        this.petService = petService;
        this.authorService = authorService;
        this.categoryService = categoryService;
//		this.publisherService = publisherService;
    }

    @RequestMapping("/pets")
    public String findAllPets(Model model) {
        final List<Pet> pets = petService.findAllPets();

        model.addAttribute("pets", pets);
        return "list-pets";
    }

    @RequestMapping("/searchPet")
    public String searchPet(@Param("keyword") String keyword, Model model) {
        final List<Pet> pets = petService.searchPets(keyword);

        model.addAttribute("pets", pets);
        model.addAttribute("keyword", keyword);
        return "list-pets";
    }

    @RequestMapping("/pet/{id}")
    public String findPetById(@PathVariable("id") Long id, Model model) {
        final Pet pet = petService.findPetById(id);

        model.addAttribute("pet", pet);
        return "list-pet";
    }

    @GetMapping("/add")
    public String showCreateForm(Pet pet, Model model) {
        model.addAttribute("categories", categoryService.findAllCategories());
        model.addAttribute("authors", authorService.findAllAuthors());
//		model.addAttribute("publishers", publisherService.findAllPublishers());
        return "add-pet";
    }

    @RequestMapping("/add-pet")
    public String createPet(Pet pet, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-pet";
        }

        petService.createPet(pet);
        model.addAttribute("pet", petService.findAllPets());
        return "redirect:/pets";
    }

    @GetMapping("/update/{id}")
    public String showUpdateForm(@PathVariable("id") Long id, Model model) {
        final Pet pet = petService.findPetById(id);

        model.addAttribute("pet", pet);
        return "update-pet";
    }

    @RequestMapping("/update-pet/{id}")
    public String updatePet(@PathVariable("id") Long id, Pet pet, BindingResult result, Model model) {
        if (result.hasErrors()) {
            pet.setId(id);
            return "update-pet";
        }

        petService.updatePet(pet);
        model.addAttribute("pet", petService.findAllPets());
        return "redirect:/pets";
    }

    @RequestMapping("/remove-pet/{id}")
    public String deletePet(@PathVariable("id") Long id, Model model) {
        petService.deletePet(id);

        model.addAttribute("pet", petService.findAllPets());
        return "redirect:/pets";
    }

}
